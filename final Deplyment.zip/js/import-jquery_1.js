//import jquery from "jquery";

// eslint-disable-next-line no-multi-assign
window.$ = window.jQuery = jQuery;
